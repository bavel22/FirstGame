package com.sabri.main;

public enum ID {
    Player(),
    Player2(),
    Enemy();

}
